import React from 'react';
import type { Node } from '../../../ModuleEditor/types';

interface RouterNodeProps {
  node: Node;
  onResponse: (response: string) => void;
  previousNode?: Node;
}

export function RouterNode({ node, onResponse, previousNode }: RouterNodeProps) {
  console.log('🚨 ROUTER NODE RENDER 🚨', {
    nodeId: node.id,
    nodeType: node.type,
    choices: node.config.choices,
    isOverlay: node.config.overlay,
    hasPreviousNode: !!previousNode,
    timestamp: new Date().toISOString()
  });

  console.warn('=== RouterNode Component Mount ===', {
    nodeId: node.id,
    nodeType: node.type,
    choices: node.config.choices
  });

  const choices = node.config.choices || [];
  
  // Helper function to get grid layout classes based on choice index and total choices
  const getChoiceLayoutClasses = (index: number, total: number) => {
    console.log(`🎯 Choice ${index + 1} Layout`, {
      choiceIndex: index,
      totalChoices: total,
      timestamp: new Date().toISOString()
    });

    // For 1 choice, center it
    if (total === 1) {
      console.log('📍 Single choice: centered');
      return 'col-span-2';
    }
    
    // For 2 choices, place side by side
    if (total === 2) {
      console.log(`📍 Two choices: side by side - Choice ${index + 1}`);
      return 'col-span-1';
    }
    
    // For 3 choices
    if (total === 3) {
      if (index < 2) {
        console.log(`📍 Three choices: top row - Choice ${index + 1}`);
        return 'col-span-1'; // First two side by side
      }
      console.log('📍 Three choices: bottom centered');
      return 'col-span-2'; // Third centered below
    }
    
    // For 4 choices
    if (total === 4) {
      console.log(`📍 Four choices: 2x2 grid - Choice ${index + 1}`);
      return 'col-span-1'; // 2x2 grid
    }
    
    // For 5 or more choices
    if (index < 2) {
      console.log(`📍 Many choices: first row - Choice ${index + 1}`);
      return 'col-span-1'; // First two side by side
    }
    if (index < 4) {
      console.log(`📍 Many choices: second row - Choice ${index + 1}`);
      return 'col-span-1'; // Next two side by side
    }
    console.log(`📍 Many choices: bottom centered - Choice ${index + 1}`);
    return 'col-span-2'; // Rest centered below
  };

  const containerClasses = node.config.overlay 
    ? 'absolute inset-0 z-50 bg-black/80 flex items-center justify-center'
    : 'space-y-8';

  const contentClasses = node.config.overlay
    ? 'bg-black/40 backdrop-blur-sm p-8 rounded-xl max-w-4xl w-full mx-auto'
    : '';

  const titleClasses = node.config.overlay
    ? 'text-2xl font-bold text-white mb-4'
    : 'text-2xl font-bold text-gray-900 mb-4';

  const questionClasses = node.config.overlay
    ? 'text-lg text-gray-200 max-w-2xl mx-auto'
    : 'text-lg text-gray-700 max-w-2xl mx-auto';

  return (
    <div className={`relative ${node.config.overlay ? 'min-h-[600px]' : ''}`}>
      <div className={containerClasses}>
      <div className={contentClasses}>
        <div className="text-center">
          <h2 className={titleClasses}>
          {node.config.title}
          </h2>
          <p className={questionClasses}>
          {node.config.question}
          </p>
        </div>

        <div className="grid grid-cols-2 gap-4 mt-8">
        {choices.map((choice, index) => {
          const layoutClass = getChoiceLayoutClasses(index, choices.length);
          console.log(`🎨 Choice ${index + 1} Final Layout`, {
            text: choice.text,
            class: layoutClass,
            position: index < 2 ? 'Top Row' : 
                      index < 4 ? 'Second Row' : 
                      'Bottom Row',
            timestamp: new Date().toISOString()
          });
          
          return (
            <button
              key={choice.id}
              onClick={() => onResponse(choice.id)}
              className={`${layoutClass} 
                px-6 py-8 text-center rounded-xl transition-all duration-200
                ${node.config.overlay 
                  ? 'bg-white/10 border border-white/20 text-white hover:bg-white/20 hover:border-white/40 backdrop-blur-sm' 
                  : 'bg-white border-2 border-gray-200 hover:border-[#008080] hover:bg-[#008080]/5'
                }
                hover:shadow-lg transform hover:-translate-y-0.5`}
            >
              <span className={`text-lg font-medium ${node.config.overlay ? 'text-white' : 'text-gray-900'}`}>
                {choice.text}
              </span>
            </button>
          );
        })}
        </div>
        </div>
      </div>
    </div>
  );
}