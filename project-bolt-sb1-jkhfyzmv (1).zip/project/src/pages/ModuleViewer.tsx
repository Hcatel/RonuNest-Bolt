// This file has been moved to /src/pages/ModuleViewer/index.tsx
// Please use the new location instead.
export { default } from './ModuleViewer/index';