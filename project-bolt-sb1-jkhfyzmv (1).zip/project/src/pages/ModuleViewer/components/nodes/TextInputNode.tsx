import React from 'react';
import { ChevronRight } from 'lucide-react';
import type { Node } from '../../../ModuleEditor/types';

interface TextInputNodeProps {
  node: Node;
  response: string;
  onResponseChange: (response: string) => void;
  onSubmit: () => void;
}

export function TextInputNode({ node, response, onResponseChange, onSubmit }: TextInputNodeProps) {
  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold text-gray-900">
        {node.config.title}
      </h2>
      <p className="text-lg text-gray-700">{node.config.question}</p>
      <div className="space-y-2">
        <textarea
          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#008080] focus:border-transparent"
          rows={4}
          placeholder="Type your answer here..."
          value={response || ''}
          onChange={(e) => onResponseChange(e.target.value)}
        />
        <button
          onClick={onSubmit}
          disabled={node.config.required && !response}
          className="flex items-center px-6 py-3 bg-[#008080] text-white rounded-lg hover:bg-[#006666] transition-colors disabled:opacity-50"
        >
          {node.connection ? 'Continue' : 'Finish'}
          <ChevronRight className="w-5 h-5 ml-2" />
        </button>
      </div>
    </div>
  );
}