import React, { useRef, useState, useEffect } from 'react';
import { ChevronRight } from 'lucide-react';
import { supabase } from '../../../../lib/supabase';
import { VideoControls } from './VideoControls';
import type { Node } from '../../../ModuleEditor/types';

interface VideoNodeProps {
  node: Node;
  onNext: () => void;
  onFinish: () => void;
  isOverlaid?: boolean;
}

export function VideoNode({ node, onNext, onFinish, isOverlaid }: VideoNodeProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isVideoReady, setIsVideoReady] = useState(false);
  const [hasMetadata, setHasMetadata] = useState(false);
  const [loadError, setLoadError] = useState<string | null>(null);
  const videoUrl = node.config.videoUrl?.startsWith('http') 
    ? node.config.videoUrl 
    : supabase.storage.from('module-thumbnails').getPublicUrl(node.config.videoUrl).data.publicUrl;

  console.log('🎥 VideoNode Render', {
    nodeId: node.id,
    controls: node.config.videoControls,
    isVideoReady,
    timestamp: new Date().toISOString()
  });

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;
    
    const handleLoadedMetadata = () => {
      console.log('🎥 Video Metadata Loaded', {
        duration: video.duration,
        readyState: video.readyState,
        currentTime: video.currentTime,
        timestamp: new Date().toISOString()
      });
      setHasMetadata(true);
      
      // Ensure duration is available
      if (isNaN(video.duration)) {
        console.warn('Video duration is NaN after metadata load');
        setLoadError('Unable to determine video duration');
      }
    };

    const handleCanPlay = () => {
      console.log('🎥 Video Can Play', {
        duration: video.duration,
        readyState: video.readyState,
        currentTime: video.currentTime,
        timestamp: new Date().toISOString()
      });
      setIsVideoReady(true);
    };

    const handleError = (e: Event) => {
      const videoElement = e.target as HTMLVideoElement;
      const error = videoElement.error;
      console.error('🎥 Video Error', {
        error,
        code: error?.code,
        message: error?.message,
        timestamp: new Date().toISOString()
      });
      setLoadError(error?.message || 'Error loading video');
    };

    video.addEventListener('loadedmetadata', handleLoadedMetadata);
    video.addEventListener('canplay', handleCanPlay);
    video.addEventListener('error', handleError);
    
    // If video is already loaded, set ready state
    if (video.readyState >= 3) {
      setIsVideoReady(true);
      setHasMetadata(true);
    }

    return () => {
      video.removeEventListener('loadedmetadata', handleLoadedMetadata);
      video.removeEventListener('canplay', handleCanPlay);
      video.removeEventListener('error', handleError);
    };
  }, []);

  // Handle video load errors
  if (loadError) {
    return (
      <div className="space-y-4">
        <h2 className="text-2xl font-bold text-gray-900">
          {node.config.title}
        </h2>
        <div className="aspect-video rounded-lg overflow-hidden bg-gray-900 flex items-center justify-center">
          <div className="text-white text-center p-4">
            <p className="text-red-400 mb-2">Unable to load video</p>
            <p className="text-sm text-gray-400">{loadError}</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold text-gray-900">
        {node.config.title}
      </h2>
      <div 
        className="relative aspect-video rounded-lg overflow-hidden" 
        onClick={(e) => e.stopPropagation()}
      >
        <video
          ref={videoRef}
          src={videoUrl}
          preload="auto"
          controls={false}
          className="w-full h-full object-contain bg-black"
          crossOrigin="anonymous"
          playsInline
          muted={node.config.videoControls?.autoplay}
          autoPlay={node.config.videoControls?.autoplay}
          onLoadStart={() => console.log('🎥 Video Load Start')}
          onLoadedData={() => console.log('🎥 Video Data Loaded')}
          onDurationChange={(e) => console.log('🎥 Duration Change:', (e.target as HTMLVideoElement).duration)}
        >
          {node.config.videoControls?.showSubtitles && (
            <track
              kind="subtitles"
              src={node.config.subtitlesUrl || ''}
              srcLang="en"
              label="English"
            />
          )}
          Your browser does not support the video tag.
        </video>
        <VideoControls
          video={videoRef.current}
          isReady={isVideoReady && hasMetadata}
          showPlayPause={node.config.videoControls?.showPlayPause}
          showVolume={node.config.videoControls?.showVolume}
          showSeeking={node.config.videoControls?.allowSeeking}
          showSubtitles={node.config.videoControls?.showSubtitles}
        />
      </div>
      {!isOverlaid && node.connection ? (
        <button
          onClick={onNext}
          className="flex items-center px-6 py-3 bg-[#008080] text-white rounded-lg hover:bg-[#006666] transition-colors"
        >
          Continue
          <ChevronRight className="w-5 h-5 ml-2" />
        </button>
      ) : !isOverlaid && (
        <button
          onClick={onFinish}
          className="flex items-center px-6 py-3 bg-[#ff4d00] text-white rounded-lg hover:bg-[#e64600] transition-colors"
        >
          Finish
          <ChevronRight className="w-5 h-5 ml-2" />
        </button>
      )}
    </div>
  );
}