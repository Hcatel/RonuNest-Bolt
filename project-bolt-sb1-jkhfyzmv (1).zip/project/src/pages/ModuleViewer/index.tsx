import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Loader2 } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { CompletionPage } from './components/CompletionPage';
import { MessageNode } from './components/nodes/MessageNode';
import { VideoNode } from './components/nodes/VideoNode';
import { RouterNode } from './components/nodes/RouterNode';
import { TextInputNode } from './components/nodes/TextInputNode';
import { MultipleChoiceNode } from './components/nodes/MultipleChoiceNode';
import { RankingNode } from './components/nodes/RankingNode';
import { useModuleNavigation } from './hooks/useModuleNavigation';
import { useModuleSharing } from './hooks/useModuleSharing';
import type { Node } from '../ModuleEditor/types';

interface ModuleData {
  id: string;
  title: string;
  description: string;
  content: {
    nodes: Node[];
  };
}

function ModuleViewer() {
  const { moduleId } = useParams();
  const navigate = useNavigate();
  const [module, setModule] = useState<ModuleData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const {
    currentNodeIndex,
    setCurrentNodeIndex,
    responses,
    handleResponse,
    handleNext
  } = useModuleNavigation(module?.content?.nodes || []);

  const {
    showShareMenu,
    setShowShareMenu,
    copySuccess,
    handleShare,
    handleCopyLink
  } = useModuleSharing();

  useEffect(() => {
    if (!moduleId) {
      setError('No module ID provided');
      return;
    }

    const loadModule = async () => {
      try {
        const { data: module, error } = await supabase
          .from('modules')
          .select('*')
          .eq('id', moduleId)
          .single();

        if (error) throw error;
        if (!module) throw new Error('Module not found');

        setModule(module);
      } catch (err) {
        console.error('Error loading module:', err);
        setError(err instanceof Error ? err.message : 'Failed to load module');
      } finally {
        setLoading(false);
      }
    };

    loadModule();
  }, [moduleId]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-[#008080]" />
      </div>
    );
  }

  if (error || !module) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-2">
            {error || 'Module not found'}
          </h1>
          <button
            onClick={() => navigate('/explore')}
            className="text-[#008080] hover:text-[#006666]"
          >
            Back to Explore
          </button>
        </div>
      </div>
    );
  }

  const nodes = module.content?.nodes || [];
  const currentNode = nodes[currentNodeIndex];
  const previousNode = nodes[currentNodeIndex - 1];

  console.log('🎭 ModuleViewer Render', {
    currentNodeType: currentNode?.type,
    currentNodeId: currentNode?.id,
    isOverlay: currentNode?.type === 'router' && currentNode?.config.overlay,
    timestamp: new Date().toISOString()
  });

  if (currentNodeIndex === nodes.length) {
    return (
      <div className="min-h-screen bg-gray-50 pt-16">
        <div className="max-w-3xl mx-auto px-4 py-12">
          <CompletionPage
            moduleTitle={module.title}
            showShareMenu={showShareMenu}
            setShowShareMenu={setShowShareMenu}
            handleShare={handleShare}
            handleCopyLink={handleCopyLink}
            copySuccess={copySuccess}
          />
        </div>
      </div>
    );
  }

  if (!currentNode) return null;

  console.warn('=== ModuleViewer Render ===', {
    currentNodeType: currentNode.type,
    currentNodeId: currentNode.id,
    isOverlay: currentNode.type === 'router' && currentNode.config.overlay,
    renderPath: 'ModuleViewer -> RouterNode'
  });

  return (
    <div className="min-h-screen bg-gray-50 pt-16">
      <div className="max-w-3xl mx-auto px-4 py-12">
        {/* Previous node content for router overlay */}
        {currentNode.type === 'router' && 
         currentNode.config.overlay && 
         previousNode && (
          <>
            {previousNode.type === 'message' && (
              <MessageNode
                key={`${previousNode.id}-overlay`}
                node={previousNode}
                onNext={() => {}}
                onFinish={() => {}}
                isOverlaid
              />
            )}
            {previousNode.type === 'video' && (
              <VideoNode
                key={`${previousNode.id}-overlay`}
                node={previousNode}
                onNext={() => {}}
                onFinish={() => {}}
                isOverlaid
              />
            )}
          </>
        )}

        {currentNode.type === 'router' && (
          <RouterNode
            key={currentNode.id}
            node={currentNode}
            onResponse={handleResponse}
            previousNode={currentNode.config.overlay ? previousNode : undefined}
          />
        )}
        {currentNode.type === 'textInput' && (
          <TextInputNode
            key={currentNode.id}
            node={currentNode}
            response={responses[currentNode.id] || ''}
            onResponseChange={(response) => setResponses(prev => ({
              ...prev,
              [currentNode.id]: response
            }))}
            onSubmit={() => handleResponse(responses[currentNode.id])}
          />
        )}
        {currentNode.type === 'multipleChoice' && (
          <MultipleChoiceNode
            key={currentNode.id}
            node={currentNode}
            selectedChoices={responses[currentNode.id] || []}
            onSelect={(choiceId) => handleResponse(
              currentNode.config.allowMultiple ? 
              [...(responses[currentNode.id] || []), choiceId] : 
              choiceId
            )}
            onNext={handleNext}
          />
        )}
        {currentNode.type === 'ranking' && (
          <RankingNode
            key={currentNode.id}
            node={currentNode}
            rankedItems={responses[currentNode.id] || 
              currentNode.config.rankingItems?.map((item, index) => ({ 
                id: index, 
                text: item 
              })) || []}
            onReorder={(items) => setResponses(prev => ({
              ...prev,
              [currentNode.id]: items
            }))}
            onNext={handleNext}
          />
        )}
        {currentNode.type === 'message' && (
          <MessageNode
            key={currentNode.id}
            node={currentNode}
            onNext={handleNext}
            onFinish={() => setCurrentNodeIndex(nodes.length)}
          />
        )}
        {currentNode.type === 'video' && (
          <VideoNode
            key={currentNode.id}
            node={currentNode}
            onNext={handleNext}
            onFinish={() => setCurrentNodeIndex(nodes.length)}
          />
        )}
      </div>
    </div>
  );
}

export default ModuleViewer;