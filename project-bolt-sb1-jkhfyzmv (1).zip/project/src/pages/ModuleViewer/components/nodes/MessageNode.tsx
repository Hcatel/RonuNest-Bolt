import React from 'react';
import { ChevronRight } from 'lucide-react';
import type { Node } from '../../../ModuleEditor/types';

interface MessageNodeProps {
  node: Node;
  onNext: () => void;
  onFinish: () => void;
  isOverlaid?: boolean;
}

export function MessageNode({ node, onNext, onFinish, isOverlaid }: MessageNodeProps) {
  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold text-gray-900">
        {node.config.title}
      </h2>
      <div className="prose prose-lg">
        {node.config.content}
      </div>
      {!isOverlaid && node.connection ? (
        <button
          onClick={onNext}
          className="flex items-center px-6 py-3 bg-[#008080] text-white rounded-lg hover:bg-[#006666] transition-colors"
        >
          Continue
          <ChevronRight className="w-5 h-5 ml-2" />
        </button>
      ) : !isOverlaid && (
        <button
          onClick={onFinish}
          className="flex items-center px-6 py-3 bg-[#ff4d00] text-white rounded-lg hover:bg-[#e64600] transition-colors"
        >
          Finish
          <ChevronRight className="w-5 h-5 ml-2" />
        </button>
      )}
    </div>
  );
}